#include "can_he_fix_it.hpp"
#include "counted_widgets.hpp"
#include "widget.hpp"
#include <algorithm>
#include <cassert>

void test_empty_toolbox(fixit_fn can_he_fix_it)
{
  widgets toolbox;
  widgets job;
  assert(can_he_fix_it(job, toolbox));
  job.push_back(widget(1));
  assert(!can_he_fix_it(job, toolbox));
}

void test_empty_job(fixit_fn can_he_fix_it)
{
  widgets toolbox(10, widget(1));
  widgets job;
  assert(can_he_fix_it(job, toolbox));
}

void test_job_bigger_than_toolbox(fixit_fn can_he_fix_it)
{
  widgets toolbox(10, widget(1));
  widgets job(11, widget(1));
  assert(!can_he_fix_it(job, toolbox));
}

void test_basic_use(fixit_fn can_he_fix_it)
{
  widget const ww[] = {
    widget(0), widget(1), widget(2), widget(3), widget(4),
    widget(5), widget(6), widget(7), widget(8), widget(9)
  };
  widgets toolbox(ww, ww + sizeof ww / sizeof ww[0]);
  widgets job(toolbox);

  assert(can_he_fix_it(job, toolbox));
  toolbox.push_back(widget(10));
  assert(can_he_fix_it(job, toolbox));

  std::reverse(job.begin(), job.end());
  assert(can_he_fix_it(job, toolbox));
  std::reverse(toolbox.begin(), toolbox.end());
  assert(can_he_fix_it(job, toolbox));

  toolbox.swap(job);
  assert(!can_he_fix_it(job, toolbox));
}

void test_repeated_widgets(fixit_fn can_he_fix_it)
{
  widget const tt[] = {
      widget(1), widget(2), widget(3),
      widget(2), widget(3), widget(1),
      widget(3), widget(1), widget(2)
  };
  widget const j1[] = {
    widget(3), widget(2),
    widget(2), widget(1),
    widget(1), widget(3)
  };
  widget const j2[] = {
    widget(4), widget(2),
    widget(2), widget(1),
    widget(1), widget(4)
  };
  widgets toolbox(tt, tt + sizeof tt / sizeof tt[0]);
  widgets job1(j1, j1 + sizeof j1 / sizeof j1[0]);
  widgets job2(j2, j2 + sizeof j2 / sizeof j2[0]);
  assert(can_he_fix_it(job1, toolbox));
  assert(!can_he_fix_it(job2, toolbox));
}

bool
can_he_fix_it5(widgets const & job, widgets const & toolbox)
{
  counted_widgets counted_job;
  counted_widgets counted_toolbox;
  count_widgets(job, counted_job);
  count_widgets(toolbox, counted_toolbox);

  return counted_toolbox.includes(counted_job);
}

int main(int, char **)
{
  fixit_fn fixit_fns[] = {
    can_he_fix_it0,
    can_he_fix_it1,
    can_he_fix_it2,
    can_he_fix_it3,
    can_he_fix_it4,
    can_he_fix_it5,
    can_he_fix_it6
  };
  for (fixit_fn * f = fixit_fns;
       f != fixit_fns + sizeof fixit_fns / sizeof fixit_fns[0];
       ++f)
  {
    test_empty_toolbox(*f);
    test_empty_job(*f);
    test_job_bigger_than_toolbox(*f);
    test_basic_use(*f);
    test_repeated_widgets(*f);
  }
  return 0;
}
