#include "can_he_fix_it.hpp"
#include "widget.hpp"
#include <algorithm>

namespace
{

// Store the widget counts in an array indexed by widget value
// and return the total number of widgets.
widgets::size_type
count_widgets(widgets const & to_count, unsigned * widget_counts)
{
  for (widget_it w = to_count.begin(); w != to_count.end(); ++w)
  {
    ++widget_counts[w->value()];
  }
  return to_count.size();
}
}

// Strategy: preprocess the job counting how many widgets there
// are of each value. Then iterate through the toolbox, reducing
// counts every time we find a widget we need.
bool
can_he_fix_it4(widgets const & job,
               widgets const & toolbox)
{
  unsigned job_widget_counts[widget::max_value];
  std::fill(job_widget_counts,
            job_widget_counts + widget::max_value, 0);

  widgets::size_type
    count = count_widgets(job, job_widget_counts);

  for (widget_it t = toolbox.begin();
       count != 0 && t != toolbox.end(); ++t)
  {
    int const tv = t->value();
    if (job_widget_counts[tv] != 0)
    {
      // We can use this widget. Adjust counts accordingly.
      --job_widget_counts[tv];
      --count;
    }
  }
  return count == 0;
}
