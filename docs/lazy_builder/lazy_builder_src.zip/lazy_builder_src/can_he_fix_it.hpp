#if !defined CAN_HE_FIX_IT_HPP_INCLUDED
#define CAN_HE_FIX_IT_HPP_INCLUDED

#include "widget.hpp"

// Can the job be done using this tool box?
// Return true if there's a widget in the toolbox for every
// widget in the job.
bool
can_he_fix_it(widgets const & job, widgets const & toolbox);

// Alternative implementations.
bool
can_he_fix_it0(widgets const & job, widgets const & toolbox);
bool
can_he_fix_it1(widgets const & job, widgets const & toolbox);
bool
can_he_fix_it2(widgets const & job, widgets const & toolbox);
bool
can_he_fix_it3(widgets const & job, widgets const & toolbox);
bool
can_he_fix_it4(widgets const & job, widgets const & toolbox);
bool
can_he_fix_it6(widgets const & job, widgets const & toolbox);

// Introduce a typedef for alternative implementations.
// and declare these implementations.
typedef bool (* fixit_fn)(widgets const &, widgets const &);

#endif // defined CAN_HE_FIX_IT_HPP_INCLUDED
