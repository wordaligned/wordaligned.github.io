#include "can_he_fix_it.hpp"
#include "widget.hpp"
#include <algorithm>
#include <set>


// Strategy: copy the job and the toolbox into a multiset
// then see if the toolbox includes the job.
bool
can_he_fix_it2(widgets const & job,
               widgets const & toolbox)
{
  std::multiset<widget> const jset(job.begin(), job.end());
  std::multiset<widget> const tset(toolbox.begin(), toolbox.end());

  return std::includes(tset.begin(), tset.end(),
                       jset.begin(), jset.end());
}
