#include "widget.hpp"
#include "can_he_fix_it.hpp"
#include "counted_widgets.hpp"
#include <algorithm>
#include <cassert>
#include <ctime>
#include <functional>
#include <iostream>
#include <iterator>

typedef double time_in_seconds;
typedef std::vector<time_in_seconds> times;
typedef std::pair<bool, clock_t> timed_test_result;
typedef std::vector<timed_test_result> timed_test_results;

namespace
{
// Generator function object.
struct random_widget
{
  // Generate a random valued widget.
  widget operator()() const
  {
    return widget(std::rand() % widget::max_value);
  }
};

// Fill the input widgets container with a counted number
// of random valued widgets.
void random_widgets(int count, widgets & to_fill)
{
  to_fill.reserve(count);
  std::back_insert_iterator<widgets> i(to_fill);
  std::generate_n(i, count, random_widget());
}

// Return the clock time for a call to the supplied fixit function.
// Doesn't handle the case when clock() wraps!
timed_test_result
timed_run(int repeat, fixit_fn f, widgets const & j, widgets const & t)
{
  clock_t start = std::clock();
  bool answer = false;
  while (repeat-- != 0)
  {
    answer = f(j, t);
  }
  return std::make_pair(answer, std::clock() - start);
}

// Variant on the previous function for the "counted_widgets" approach.
// Still doesn't handle the case when clock() wraps!
timed_test_result
timed_counted_widgets_run(int repeat, widgets const & j, widgets const & t)
{
  counted_widgets cj;
  counted_widgets ct;
  count_widgets(j, cj);
  count_widgets(t, ct);

  clock_t start = std::clock();
  bool answer = false;
  while (repeat-- != 0)
  {
    answer = ct.includes(cj);
  }
  return std::make_pair(answer, std::clock() - start);
}

// Merge a timed test result into the set.
void
merge_result(timed_test_results::iterator i, timed_test_result ttr)
{
  i->first = ttr.first;
  i->second += ttr.second;
}

// Confirm the results returned by the different algorithms are consistent.
void
check_results_consistent(timed_test_results const results)
{
  assert(results.size() != 0);
  timed_test_results::const_iterator r = results.begin();
  bool const first_answer = r->first;
  while (++r != results.end())
  {
    assert(r->first == first_answer);
  }
}

// Function object converts clock_t values to seconds.
struct clocks_to_secs
{
  double operator()(timed_test_result ttr)
  {
    return static_cast<double>(ttr.second) / CLOCKS_PER_SEC;
  }
};

// Call the different implementations of can_he_fix_it repeatedly, using
// random inputs, measuring how long they take to complete.
void timed_test(int number_of_runs, int repeat_each_run, int toolbox_size, times & res)
{
  fixit_fn fixit_fns[] = {
    can_he_fix_it0,
    can_he_fix_it1,
    can_he_fix_it2,
    can_he_fix_it3,
    can_he_fix_it4
  };
  size_t const n_fixit_fns = sizeof fixit_fns / sizeof fixit_fns[0];

  timed_test_result const zero_time(false, 0);
  timed_test_results
    test_results(n_fixit_fns + 1, // extra "1" for timed_counted_widgets_run
                 zero_time);
  widgets job;
  widgets toolbox;

  while (number_of_runs-- != 0)
  {
    random_widgets(toolbox_size, toolbox);
    random_widgets(toolbox_size / 10, job);

    timed_test_results::iterator it = test_results.begin();

    for (fixit_fn * f = fixit_fns; f != fixit_fns + n_fixit_fns; ++f)
    {
      merge_result(it++, timed_run(repeat_each_run, *f, job, toolbox));
    }
    merge_result(it++, timed_counted_widgets_run(repeat_each_run, job, toolbox));
    check_results_consistent(test_results);
  }
  res.clear();
  std::transform(test_results.begin(), test_results.end(),
                 std::back_inserter(res), clocks_to_secs());
}

} // end anonymous namespace

int main(int, char **)
{
  times res;
  int tbox_size = 0;

  do
  {
    tbox_size += 5000;
    timed_test(10, 50, tbox_size, res);
    std::cout << tbox_size << " ";
    typedef std::ostream_iterator<time_in_seconds> out;
    std::copy(res.begin(), res.end(), out(std::cout, " "));
    std::cout << std::endl;
  } while (tbox_size != 50000);
  return 0;
}
