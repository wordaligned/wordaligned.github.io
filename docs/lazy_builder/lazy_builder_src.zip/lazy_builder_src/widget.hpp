#if !defined WIDGET_HPP_INCLUDED
#define WIDGET_HPP_INCLUDED

#include <vector>

class widget
{
public: // Construct
  explicit widget(int value);
  enum { max_value = 500 };
public: // Access
  int value() const;
public: // Compare
  bool operator<(widget const & other) const;
  bool operator==(widget const & other) const;
private:
  int value_;
};

typedef std::vector<widget> widgets;
typedef widgets::const_iterator widget_it;

#endif // defined WIDGET_HPP_INCLUDED
