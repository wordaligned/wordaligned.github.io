#include "can_he_fix_it.hpp"
#include "widget.hpp"
#include <set>
#include <algorithm>

// Strategy: For each widget in the job, iterate through the widgets in the
// toolbox looking for a matching widget. If we find a match which we haven't
// used already, make a note of it and continue to the next job widget. If we
// don't, fail.
bool
can_he_fix_it0(widgets const & job,
               widgets const & toolbox)
{
  bool yes_he_can = true;
  // Track widgets from the toolbox which we've used already 
  std::set<widget_it> used;
  widget_it const t_end = toolbox.end();

  for (widget_it j = job.begin(); yes_he_can && j != job.end(); ++j)
  {
    yes_he_can = false;
    widget_it t = toolbox.begin();
    while (!yes_he_can && t != t_end)
    {
      t = std::find(t, t_end, *j);
      yes_he_can = t != t_end && used.find(t) == used.end();
      if (yes_he_can)
      {
        used.insert(t);
      }
      if (t != t_end)
      {
        ++t;
      }
    }
  }
  return yes_he_can;
}
