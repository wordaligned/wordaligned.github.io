#include "widget.hpp"
#include <algorithm>


// Strategy: shuffle through permutations of the toolbox, until we find one
// whose first entries exactly match those in the job.
bool
can_he_fix_it6(widgets const & job,
               widgets const & toolbox)
{
  // Handle edge case separately: if the job's bigger than
  // the toolbox, we can't call std::equal later in this function.  
  if (job.size() > toolbox.size())
  {
    return false;
  }
  widgets permed(toolbox);
  std::sort(permed.begin(), permed.end());

  widget_it const jb = job.begin();
  widget_it const je = job.end();

  bool he_can = false;
  bool more = true;
  while (!he_can && more)
  {
    he_can = std::equal(jb, je, permed.begin());
    more = std::next_permutation(permed.begin(), permed.end());
  }
  return he_can;
}
