#include "counted_widgets.hpp"
#include <algorithm>
#include <functional>

counted_widgets::counted_widgets()
{
  std::fill(widget_counts, widget_counts + widget::max_value, 0);
}

void
counted_widgets::add(widget const & to_add, unsigned how_many)
{
  widget_counts[to_add.value()] += how_many;
}
    
unsigned
counted_widgets::count(widget const & to_count) const
{
  return widget_counts[to_count.value()];
}
  
unsigned
counted_widgets::remove(widget const & to_remove, unsigned how_many)
{
  unsigned const can_remove = std::min(count(to_remove), how_many);
  widget_counts[to_remove.value()] -= can_remove;
  return can_remove;
}
  
bool
counted_widgets::includes(counted_widgets const & other) const
{
  return std::equal(widget_counts,
                    widget_counts + widget::max_value,
                    other.widget_counts,
                    std::greater_equal<unsigned>());
}

void
count_widgets(widgets const & to_count, counted_widgets & count_into)
{
  for (widget_it w = to_count.begin(); w != to_count.end(); ++w)
  {
    count_into.add(*w, 1);
  }
}
