#if !defined COUNTED_WIDGETS_HPP_INCLUDED
#define COUNTED_WIDGETS_HPP_INCLUDED

#include "widget.hpp"

// This class represents a counted collection of widgets.
class counted_widgets
{
public:
  // Construct an empty collection of widgets.
  counted_widgets();
public:
  // Add a number of widgets to the collection.
  void add(widget const & to_add, unsigned how_many);
    
  // Count up widgets of the given type. 
  unsigned count(widget const & to_count) const;
  
  // Try and remove a number of widgets of the given type.
  // Returns the number actually removed.
  unsigned remove(widget const & to_remove, unsigned how_many);
  
  // Does this counted collection of widgets include
  // another such collection?
  bool includes(counted_widgets const & other) const;
private:
  unsigned widget_counts[widget::max_value];
};

// Count all the input widgets into the counted_widgets container.
void count_widgets(widgets const & to_count,
                   counted_widgets & count_into);

#endif // COUNTED_WIDGETS_HPP_INCLUDED
