#include "can_he_fix_it.hpp"
#include "widget.hpp"
#include <algorithm>

// Strategy: sort both the job and the toolbox. Then iterate through the
// widgets in the sorted job. For each widget value in the job, see how many
// widgets there are of this value, then see if we have enough widgets of this
// value in the toolbox.
bool
can_he_fix_it1(widgets const & job,
               widgets const & toolbox)
{
  widgets sorted_job(job);
  widgets sorted_toolbox(toolbox);
  std::sort(sorted_job.begin(), sorted_job.end());
  std::sort(sorted_toolbox.begin(), sorted_toolbox.end());

  bool yes_he_can = true;
  widget_it j = sorted_job.begin();
  widget_it const j_end = sorted_job.end();
  widget_it t = sorted_toolbox.begin();
  widget_it const t_end = sorted_toolbox.end();

  while (yes_he_can && j != j_end)
  {
    widget_it next_j = std::upper_bound(j, j_end, *j);

    std::pair<widget_it, widget_it> matching_tools
      = std::equal_range(t, t_end, *j);

    yes_he_can
      = next_j - j <= matching_tools.second - matching_tools.first;

    j = next_j;
    t = matching_tools.second;
  }
  return yes_he_can;
}
