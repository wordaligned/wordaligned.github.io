#include "can_he_fix_it.hpp"
#include "widget.hpp"
#include <algorithm>


// Strategy: sort the job and the toolbox, then see if the
// toolbox includes the job.
bool
can_he_fix_it3(widgets const & job,
               widgets const & toolbox)
{
  widgets sj(job);
  widgets st(toolbox);
  std::sort(sj.begin(), sj.end());
  std::sort(st.begin(), st.end());
  return std::includes(st.begin(), st.end(), sj.begin(), sj.end());
}
