#include "widget.hpp"
#include <stdexcept>

widget::widget(int value)
  : value_(value)
{
  if (value >= max_value)
  {
    throw std::invalid_argument
      ("Value exceeds maximum widget value");
  }
}

int widget::value() const
{
  return value_;
}

bool widget::operator<(widget const & other) const
{
  return value_ < other.value_;
}

bool widget::operator==(widget const & other) const
{
  return value_ == other.value_;
}

