/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief This file provides an interface to the DVB section encoder.
 */

#ifndef SECTIONENCODE_HPP_INCLUDED
#define SECTIONENCODE_HPP_INCLUDED


/**
 * @brief Encode a text version of DVB section
 * @param file_name The name of the file
 */
void
sectionEncode(char const * file_name);

/**
 * @brief Run the encoder self-checks
 */
void
selfCheckEncoder();


#endif // SECTIONENCODE_HPP_INCLUDED

