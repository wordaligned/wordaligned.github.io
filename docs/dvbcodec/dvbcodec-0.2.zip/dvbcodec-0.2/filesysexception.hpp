/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief  This file defines various file system exceptions.
 */

#ifndef FILESYSEXCEPTION_HPP_INCLUDED
#define FILESYSEXCEPTION_HPP_INCLUDED

#include <stdexcept>

class FailedToOpenFile
    : public std::runtime_error
{
public:
    FailedToOpenFile(std::string const & file_name)
        : std::runtime_error(
             std::string("Failed to open file [") 
             + file_name
             + "]\n")
    {
    }
};


class EmptyFileException
    : public std::runtime_error
{
public:
    EmptyFileException(std::string const & file_name)
        : std::runtime_error(
             std::string("File [") 
             + file_name
             + "] is empty\n")
    {
    }
};

#endif // defined FILESYSEXCEPTION_HPP_INCLUDED

