/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief This file defines some typedefs used in the codec 
 * for convenience.
 */

#ifndef CODECTYPEDEFS_HPP_INCLUDED
#define CODECTYPEDEFS_HPP_INCLUDED

#include <boost/spirit/tree/ast.hpp>
#include <boost/spirit/iterator/file_iterator.hpp>

typedef unsigned char byte;
typedef boost::spirit::file_iterator<byte> file_it;

typedef char const * iterator_t;
typedef boost::spirit::tree_match<iterator_t> parse_tree_match_t;
typedef parse_tree_match_t::tree_iterator iter_t;


#endif /* defined CODECTTYPEDEFS_HPP_INCLUDED */

