/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief This file provides an interface to the DVB section decoder.
 */

#ifndef SECTIONDECODE_HPP_INCLUDED
#define SECTIONDECODE_HPP_INCLUDED


/**
 * @brief Decode a binary DVB section
 * @param file_name The name of the file
 *
 * @note This function may throw file system exceptions (see
 * filesysexception.hpp), but should not throw decoder exceptions.
 */
void
sectionDecode(char const * file_name);

/**
 * @brief Run the decoder self-checks
 */
void
selfCheckDecoder();

#endif // SECTIONDECODE_HPP_INCLUDED

