/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief This file defines exceptions which can occur when decoding
 * sections
 */

#ifndef DECODEEXCEPTION_HPP_INCLUDED
#define DECODEEXCEPTION_HPP_INCLUDED

#include <stdexcept>
#include <string>

class UnknownSectionException
    : public std::runtime_error
{
public:
    UnknownSectionException(std::string const & section)
        : std::runtime_error
            (std::string("Section [")
             + section
             + "] not supported")
    {
    }
};


class SectionFormatParseException
    : public std::runtime_error
{
public:
    SectionFormatParseException(std::string const & format)
        : std::runtime_error
            (std::string("Failed to parse format of section [")
             + format
             + "]")
    {
    }                            
};


class EndOfDataException
    : public std::runtime_error
{
public:
    EndOfDataException()
        : std::runtime_error(
            std::string("Section incomplete")
            )
    {
    }
};


class MalformedConditional
    : public std::runtime_error
{
public:
    MalformedConditional(std::string const & field)
        : std::runtime_error(
            std::string("Section conditional references unknown field ["
                        + field
                        + "]"
                        )
            )
    {
    }
};


class BadlyAlignedBlockExit
    : public std::runtime_error
{
public:
    BadlyAlignedBlockExit(std::string const & field)
        : std::runtime_error(
            std::string("Length field ["
                        + field
                        + "] is not at an 8 bit boundary"
                        )
            )
    {
    }
};


class tooManyBits
    : public std::runtime_error
{
public:
    tooManyBits(unsigned bitwidth)
        : std::runtime_error(
            "Too many bits to decode as an unsigned long"
            )
        , bitwidth_(bitwidth)
    {
    }
    unsigned bitwidth_;
};


class SectionFinishedBeforeEof
    : public std::runtime_error
{
public:
    SectionFinishedBeforeEof()
        : std::runtime_error(
            std::string(
                "Section decoded before end of file reached"
                )
            )
    {
    }
};

#endif // defined DECODEEXCEPTION_HPP_INCLUDED

