/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief DVB section decoder support.
 */
#include "codectypedefs.hpp"
#include "decodecontext.hpp"
#include "decodeexception.hpp"
#include "filesysexception.hpp"
#include "section.hpp"
#include "sectionformat.hpp"
#include "stringutils.hpp"

//#define BOOST_SPIRIT_DEBUG        // define this for debug output
#include <boost/spirit/core.hpp>
#include <boost/spirit/tree/ast.hpp>
#include <boost/spirit/iterator/file_iterator.hpp>

#include <cstdlib>
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>

using namespace boost::spirit;

namespace
{
/**
 * @brief Simple RAII class to help with text output of section blocks.
 */
class EnterBlock
{
public:
    /**
     * @brief Constructor opens a section block
     */
    EnterBlock(DecodeContext & context)
        : context_(context)
    {
        context_.decodeOut() << " {\n";
        context_.openBlock();
    }

    /**
     * @brief Destructor closes a section block
     */
    ~EnterBlock()
    {
        context_.closeBlock();
        context_.decodeOut() << context_.indent() << "}\n";
    }
private:
    DecodeContext & context_;
};


/**
 * @brief Obtain a node's name
 */
std::string
name(iter_t const & i)
{
    return std::string(i->value.begin(),
                       i->value.end());
}


/**
 * @brief Convert a string of the form '1010011' (e.g.) into an unsigned long
 */
unsigned long
decodeQuotedBinary(std::string const & quoted_binary_value)
{
    std::string::size_type const len = quoted_binary_value.size();

    assert(len >= 2);
    assert(quoted_binary_value[0] == '\'');
    assert(quoted_binary_value[len - 1] == '\'');
    
    // strip the quotes
    std::string const bin_val =
        quoted_binary_value.substr(1, len - 1);
    
    return std::strtoul(bin_val.c_str(), 0, 2);
}


/**
 * @brief Convert a string of the form 1234 (e.g.) into an unsigned long
 */
unsigned long
decodeUnsignedLong(std::string const & ulong)
{
    return std::strtoul(ulong.c_str(), 0, 10);
}


/**
 * @brief Check if the section ends with a CRC, and adjust the decode context
 * accordingly.
 */
void
checkForCRC(std::string const & section_format, DecodeContext & context)
{
    if (section_format.find("CRC_32") != std::string::npos)
    {
        context.registerCRC();
    }
}


// Forward declarations
void decodeSection(char const * format, DecodeContext & context);
void decodeExpression(iter_t const & i, DecodeContext & context);


/**
 * @brief Decode a section body
 */
 void
decodeSectionBody(iter_t const & body, DecodeContext & context)
{
    for (iter_t child = body->children.begin();
         child != body->children.end();
         ++child)
    {
        decodeExpression(child, context);
    }
}


/**
 * @brief Decode a section field
 */
void
decodeField(iter_t const & field, DecodeContext & context)
{
    assert(field->children.size() >= 2);
    
    iter_t fi = field->children.begin();
    
    std::string const field_name = name(fi++);
    std::string const bitwidth = name(fi++);
    
    std::string const value =
        context.readFieldValue(field_name,
                               decodeUnsignedLong(bitwidth));

    context.decodeOut()
        << context.indent()
        << field_name << " "
        << bitwidth
        << " = 0x" << value << "\n";
    
    assert(fi == field->children.end());
}


/**
 * @brief Decode a conditional in the section
 */
void
decodeConditional(iter_t const & conditional, DecodeContext & context)
{
    // if cond {...} <else {...}>, where cond is
    // (field == quoted_binary_value)
    assert(conditional->children.size() >= 3);

    iter_t cond = ++conditional->children.begin();
    iter_t ci = cond->children.begin();
    
    std::string const item(name(ci++)); 
    std::string const op(name(ci++)); 
    std::string const val(name(ci++)); 
        
    unsigned long const value = decodeQuotedBinary(val);
        
    context.decodeOut()
        << context.indent()
        << "if (" << item + op + val << ")";
            
    if (context.testCondition(item, op, value))
    {
        EnterBlock block(context);
        decodeSectionBody(cond + 1, context);
    }
    else
    {
        {
            EnterBlock block(context); // Print an empty if block
        }
        if (conditional->children.size() == 5)
        {
            // We have an else block 
            context.decodeOut() << context.indent() << "else";
            EnterBlock block(context);
            decodeSectionBody(cond + 3, context);
        }
    }
}


/**
 * @brief Decode a loop in the section
 */
void
decodeLoop(iter_t const & loop, DecodeContext & context)
{
    // loop control, loop body
    assert(loop->children.size() == 2);
        
    iter_t control = loop->children.begin();
    iter_t body = control + 1;
        
    context.decodeOut() << context.indent() << name(control);
    EnterBlock block(context);
        
    while (!context.testLoopExit())
    {
        decodeSectionBody(body, context);
    }
}


/**
 * @brief Decode a section reference (usually a descriptor)
 */
void
decodeSectionRef(iter_t const & ref, DecodeContext & context)
{
    std::string const & section_name(name(ref->children.begin()));

    char const * format = SectionFormat(section_name.c_str());

    if (format == 0)
    {
        throw UnknownSectionException(section_name);
    }
    decodeSection(format, context);
}


/**
 * @brief Decode an expression.
 *
 * @note Only certain expressions are processed -- others may safely be
 * omitted. The section grammar could be improved to only create relevant
 * nodes.
 */
void
decodeExpression(iter_t const & expr,
                 DecodeContext & context)
{
    if (expr->value.id() == Section::section_ref_ID)
    {
        decodeSectionRef(expr, context);
    }
    else if (expr->value.id() == Section::field_ID)
    {
        decodeField(expr, context);
    }
    else if (expr->value.id() == Section::conditional_ID)
    {
        decodeConditional(expr, context);
    }
    else if (expr->value.id() == Section::loop_ID)
    {
        decodeLoop(expr, context);
    }
}


void
decodeSection(char const * section_format,
              DecodeContext & context)
{
    assert(section_format != 0);
    
    Section section;
        
    tree_parse_info<> info = ast_parse(section_format,
                                       section,
                                       space_p);

    if (info.full)
    {
        assert(info.trees.begin()->children.size() == 2);
        
        iter_t sec_it = info.trees.begin()->children.begin();
        
        context.decodeOut()
            << context.indent()
            << name(sec_it++->children.begin())
            << "()";
        
        EnterBlock block(context);
        checkForCRC(section_format, context);
        decodeSectionBody(sec_it++, context);
    }
    else
    {
        throw SectionFormatParseException(section_format);
    }
}

/**
 * @brief Check a section format is known and parseable
 */
void
checkSectionFormat(char const * section_name)
{
    assert(section_name != 0);
    
    char const * section_format = SectionFormat(section_name);
    
    if (section_format == 0)
    {
        throw UnknownSectionException(section_name);
    }
    else
    {
        Section section;            
        tree_parse_info<> info = ast_parse(section_format,
                                           section,
                                           space_p);
        if (!info.full)
        {
            throw SectionFormatParseException(section_name);
        }
    }
}


DecodeContext
createDecodeContext(char const * file_name,
                    std::ostringstream & out,
                    char const * & section_format)
{
    file_it file_begin(file_name);

    if (!file_begin)
    {
        throw FailedToOpenFile(file_name);
    }
    file_it file_end = file_begin.make_end();

    if (file_begin == file_end)
    {
        throw EmptyFileException(file_name);
    }
    
    char const * section_name = SectionName(*file_begin);
    section_format = SectionFormat(section_name);
        
    if (section_format == 0)
    {
        throw UnknownSectionException(section_name);
    }
    
    return DecodeContext(file_begin, file_end, out);
}


} // anonymous namespace


void
sectionDecode(char const * file_name)
{
    char const * section_format = 0;
    std::ostringstream out;
        
    DecodeContext context
        = createDecodeContext(file_name, out, section_format);

    std::string text_file_name
        = changeExtension(file_name, ".txt");

    // Note: any decode errors are handled at this level --
    // the output "errordump" should provide useful context.
    // File system errors (e.g failure to open a file) must be
    // handled by callers of this function.
    try
    {
        decodeSection(section_format, context);
        if (!context.finished())
        {
            throw SectionFinishedBeforeEof();
        }
    }
    catch (std::exception & exc)
    {
        std::cerr
            << "Failed to decode [" << file_name << "]\n"
            << exc.what()
            << std::endl;
        text_file_name
            = changeExtension(file_name, ".errordump");
    }
    
    std::ofstream outf(text_file_name.c_str());
    
    if (!outf)
    {
        throw FailedToOpenFile(text_file_name);
    }
    outf << out.str();
    std::cout
        << "Decode: [" << file_name
        << "] --> [" << text_file_name << "]" << std::endl;
}


void
selfCheckDecoder()
{
    typedef std::vector<char const *> Formats;
    Formats known_formats;
    
    getKnownSectionFormats(known_formats);

    unsigned pass_count = 0;
    unsigned fail_count = 0;
    
    for (Formats::const_iterator f = known_formats.begin();
         f != known_formats.end(); ++ f)
    {
        try
        {
            checkSectionFormat(* f);
            ++ pass_count;
        }
        catch(std::exception & exc)
        {
            ++ fail_count;
            std::cerr
                << "Error: Section format [" << * f << "] fails self-test.\n"
                << "Reason: [" << exc.what() << "]" << std::endl;
        }
    }
    
    std::cout
        << results("DECODER SELF TEST", pass_count, fail_count)
        << std::endl;
}
