/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief  This file defines the Section grammar.
 */

#ifndef SECTION_HPP_INCLUDED
#define SECTION_HPP_INCLUDED

#include <boost/spirit/core.hpp>

/**
 * @brief DVB Section grammar defined using Boost Spirit.
 *
 * References:
 *   - ISO/IEC 13818-1, MPEG-2 Transport Stream
 *   - http://www.boost.org, Boost
 */
struct Section :
    public boost::spirit::grammar<Section>
{
    static const int section_ref_ID   = 1;
    static const int section_body_ID  = 2;
    static const int field_ID         = 3;
    static const int loop_ID          = 4;
    static const int conditional_ID   = 5;
        
    template <typename ScannerT>
    struct definition
    {
        definition(Section const & /*self*/)
        {
            section_
                =   section_ref_
                    >> section_body_
                ;

            section_ref_
                =   text_id_
                    >>   '('
                    >>   ')'
                ;
        
            text_id_
                =   leaf_node_d[
                        lexeme_d[
                            alpha_p
                            >> * (alnum_p | '_')
                            ]
                        ]
                ;

            quoted_binary_
                =   leaf_node_d[
                        lexeme_d[    
                            '\''
                            >>  bin_p
                            >> '\''
                        ]
                    ]
                ;
            
            section_body_
                =   ch_p('{')
                    >> *(       field_
                            |   loop_
                            |   conditional_
                            |   section_ref_
                        )
                    >> '}'
                ;
            
            field_
                =   identifier_
                    >>   uint_p
                ;

            identifier_
                =   text_id_
                    |   quoted_binary_
                ;

            conditional_
                =   str_p("if")
                    >> condition_
                    >> section_body_
                    >>  ! (str_p("else")
                           >>   section_body_)
                ;

            condition_
                =   inner_node_d['('
                        >> text_id_
                        >> "=="
                        >> quoted_binary_
                        >> ')'
                        ]
                ;

            loop_
                =   loop_control_
                    >> section_body_
                ;

            loop_control_
                =   leaf_node_d[str_p("for")
                    >>   '('
                    >>   * (anychar_p - ')')
                    >>   ')'
                    ]
                ;

        }

        boost::spirit::rule<ScannerT> section_;
        boost::spirit::rule<ScannerT> text_id_;
        boost::spirit::rule<ScannerT> quoted_binary_;
        boost::spirit::rule<ScannerT> identifier_;
        boost::spirit::rule<ScannerT> condition_;
        boost::spirit::rule<ScannerT> loop_control_;
    
        boost::spirit::rule<ScannerT, boost::spirit::parser_tag<section_ref_ID> > section_ref_;
        boost::spirit::rule<ScannerT, boost::spirit::parser_tag<section_body_ID> > section_body_;
        boost::spirit::rule<ScannerT, boost::spirit::parser_tag<field_ID> > field_;
        boost::spirit::rule<ScannerT, boost::spirit::parser_tag<loop_ID> > loop_;
        boost::spirit::rule<ScannerT, boost::spirit::parser_tag<conditional_ID> > conditional_;
        
        boost::spirit::rule<ScannerT> const &
        start() const
        {
            return section_;
        }
    };
};

#endif /* defined SECTION_HPP_INCLUDED */

