/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief This file defines exceptions which can occur when encoding
 * sections
 */

#ifndef ENCODEEXCEPTION_HPP_INCLUDED
#define ENCODEEXCEPTION_HPP_INCLUDED

#include <stdexcept>
#include <string>

class notEnoughBits
    : public std::runtime_error
{
public:
    notEnoughBits(unsigned bitwidth)
        : std::runtime_error("Not enough bits to encode value")
        , bitwidth_(bitwidth)
    {
    }
    unsigned bitwidth_;
};



#endif // defined ENCODEEXCEPTION_HPP_INCLUDED

