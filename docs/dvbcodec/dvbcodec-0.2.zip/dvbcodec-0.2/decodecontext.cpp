/**
 * Copyright (c) 2004, Thomas Guest. All rights reserved.
 * @file
 * @brief This file contains the implementation of the class DecodeContext.
 */

#include "decodecontext.hpp"
#include "decodeexception.hpp"
#include "stringutils.hpp"

#include <cassert>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace
{

std::string
putCurrentByte(unsigned val, unsigned & to_put, unsigned & puttable_width)
{
    std::stringstream value;
    value.fill('0');
    
    if (puttable_width >= to_put)
    {
        assert(puttable_width <= 8);
        
        val &= ~(~0u << puttable_width);
        val >>= puttable_width - to_put;
        // Careful! These are stream insertion operators, not
        // shift operators.
        value << std::hex << std::setw(2) << val;
        
        puttable_width -= to_put;
        to_put = 8;
    }

    return value.str();
}

}



DecodeContext::DecodeContext(file_it data_begin,
                             file_it data_end,
                             std::ostream & decode_out)
    : current_byte_(0)
    , bits_left_(0)
    , depth_(0)
    , offset_for_crc_(0)
    , data_begin_(data_begin)
    , data_end_(data_end)
    , decode_out_(decode_out)
{
}


std::ostream &
DecodeContext::decodeOut() const
{
    return decode_out_;
}


std::string
DecodeContext::readFieldValue(std::string const & field, unsigned width)
{    
    std::string hex_val;
    unsigned long val = 0;
    
    // This is rather fiddly, since fields are not byte aligned.
    // The data members current_byte_ and bits_left_ record where we
    // are in the input.
    
    // We now have to read another width bits, composing a
    // hex string to hold the result: we only actually add to this string
    // when we've read a byte of data -- with the exception of the most 
    // significant bits, which may be a partial byte.    
    unsigned puttable_width = 0u;
    unsigned to_put = width % 8u;
    if (to_put == 0)
    {
        to_put = 8u;
    }
    
    while (width != 0)
    {
        getCurrentByte(); // refresh current_byte_, bits_left_ 
                          // if necessary
        
        unsigned const read  = std::min(bits_left_, width);
        unsigned const shift = bits_left_ - read;
        
        // Note that val itself will overflow if:
        //    width > sizeof(unsigned long) * 8
        // Our hex representation will still be valid, though.
        
        // We will only have a problem if such a value is used in a 
        // conditional test -- this does not happen for the sections
        // supported.
        val <<= read;
        val |= current_byte_ >> shift;
        puttable_width += read;

        hex_val += putCurrentByte(val, to_put, puttable_width);
        
        unsigned mask = ~(~0u << read);    // Clear the bits we've read     
        current_byte_ &= ~(mask << shift); // (only needed for cross-checking).

        width -= read;
        bits_left_ -= read;        
    }

    pushFieldValue(field, val);
    
    return hex_val;
}


bool
DecodeContext::finished() const
{
    return data_begin_ == data_end_;
}


void
DecodeContext::openBlock()
{
    ++depth_;
}


void
DecodeContext::closeBlock()
{
    assert(depth_ != 0);
    --depth_;
}


std::string 
DecodeContext::indent() const
{
    std::string const tab("   ");
    return tab * depth_;
}


bool
DecodeContext::testCondition(std::string const & field,
                             std::string const & op,
                             unsigned long const & value) const
{
    (void)op; // We aren't using this parameter, as yet
    
    field_values::const_iterator fv = field_values_.find(field);

    if (fv == field_values_.end())
    {
        throw MalformedConditional(field);
    }
    
    return 
        fv != field_values_.end() &&
        fv->second == value;
}


void
DecodeContext::registerCRC()
{
    offset_for_crc_ = 4;
}


void
DecodeContext::pushLoopExit(unsigned bytes_to_loop_exit)
{
    bytes_to_loop_exit -= offset_for_crc_;
    offset_for_crc_ = 0;
    loop_exits_.push(data_begin_ + bytes_to_loop_exit);
}


bool
DecodeContext::testLoopExit()
{
    assert(!loop_exits_.empty());
    
    bool const loop_exit =
        data_begin_ == loop_exits_.top();

    if (loop_exit)
    {
        loop_exits_.pop();
    }
    
    return loop_exit;
}


/**
 * @brief Store field, value
 */
void
DecodeContext::pushFieldValue(std::string const & field,
                              unsigned long const & value)
{
    field_values_[field] = value;
    
    // Section lengths are in bytes, and must be byte aligned.
    if (endsWith(field, "length"))
    {
        if (bits_left_ != 0)
        {
            throw BadlyAlignedBlockExit(field);
        }
        pushLoopExit(value);
    }
}


/**
 * @brief Read the next byte from input, if we've finished with the current
 * one.
 */
void
DecodeContext::getCurrentByte()
{
    if (bits_left_ == 0)
    {
        assert(current_byte_ == 0); // sanity check we've cleared the
                                        // current byte
        if (data_begin_ == data_end_)
        {
            throw EndOfDataException();
        }
        current_byte_ = *data_begin_++;
        bits_left_ = 8;
    }
}
