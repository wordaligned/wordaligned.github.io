/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file implements the SectionDecodeGenerator class.
 */

#include "sectiondecodegenerator.hpp"

#include "codectypedefs.hpp"
#include "cppfileutils.hpp"
#include "decodeexception.hpp"
#include "section.hpp"
#include "sectionformat.hpp"
#include "stringutils.hpp"

#include <set>
#include <string>
#include <cassert>

namespace
{

/**
 * @brief Returns a double quoted version of the input string
 */
std::string
quote(std::string const & to_quote)
{
    return std::string("\"") + to_quote + "\"";
}


/**
 * @brief Convert a string of the form 1234 (e.g.) into an unsigned long
 */
unsigned long
decodeUnsignedLong(std::string const & ulong)
{
    return std::strtoul(ulong.c_str(), 0, 10);
}

/**
 * @brief Simple type used to wrap up an output stream
 * and an indentation level.
 */
struct CppFile
{
    CppFile(std::ostream & out)
              : out_(out)
              , depth_(0)
    {
    }
    
    void enterBlock()
    {
        out_ << indent_ + "{\n";
        indent_ = std::string("    ") * ++depth_;
    }
    
    void leaveBlock()
    {
        assert(depth_ != 0);
        indent_ = std::string("    ") * --depth_;
        out_ << indent_ + "}\n";
    }
    
    std::string indent_;
    std::ostream & out_;
    unsigned depth_;
};

} // anonymous namespace

namespace dvbcodec
{
using namespace boost::spirit;

typedef std::set<std::string> FieldNames;

/**
 * @brief Functor implementing section loop control action.
 */
struct Loop
{
    Loop(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(Iterator const & first, 
               Iterator const & last) const
    {
        std::string const tab = cpp_.indent_;
        
        cpp_.out_
            << tab
            << "out.putLoopControl("
            << quote(std::string(first, last))
            << ");\n"
        
            << tab
            << "out.enterBlock();\n"
                 
            << tab
            << "while(!out.testLoopExit())\n";
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section loop start action.
 */
struct LoopStart
{
    LoopStart(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(char) const
    {
        cpp_.enterBlock();
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section loop end action.
 */
struct LoopEnd
{
    LoopEnd(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(char) const
    {
        cpp_.leaveBlock();
        cpp_.out_ 
            << cpp_.indent_ 
            << "out.leaveBlock();\n";      
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section if condition action.
 */
struct If
{
    If(CppFile & cpp, 
       std::string & item, 
       std::string & op,
       std::string & value,
       FieldNames & fields)
        : cpp_(cpp)
        , item_(item)
        , op_(op)
        , value_(value)
        , fields_(fields)
    {
    }
              
    void
    operator()(Iterator const &, 
               Iterator const &) const
    {
        if (fields_.find(item_) == fields_.end())
        {
            // We can't test the value of a non-existent field!
            throw MalformedConditional(item_);
        }
        
        cpp_.out_ << cpp_.indent_
                  << "if (out.putIf("
                  << quote(item_)
                  << ", "
                  << quote(op_)
                  << ", "
                  << quote(value_)
                  << "))\n";
    }
    
    CppFile & cpp_;
    std::string & item_, & op_, & value_;
    FieldNames const & fields_;
};


/**
 * @brief Functor implementing section else condition action.
 */
struct Else
{
    Else(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(Iterator const & first, 
               Iterator const & last) const
    {
        cpp_.out_
            << cpp_.indent_
            << "else if (out.putElse())\n";
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section enter block action.
 */
struct EnterBlock
{
    EnterBlock(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(char) const
    {
        cpp_.enterBlock();
        cpp_.out_
            << cpp_.indent_
            << "out.enterBlock();\n";
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section leave block action.
 */
struct LeaveBlock
{
    LeaveBlock(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(char) const
    {
        cpp_.out_
            << cpp_.indent_
            << "out.leaveBlock();\n";
        cpp_.leaveBlock();
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section field action.
 */
struct Field
{
    Field(CppFile & cpp,
          std::string const & name,
          FieldNames & fields)
        : cpp_(cpp)
        , name_(name)
        , fields_(fields)
    {
    }
    
    void
    operator()(unsigned const & bitwidth) const
    {
        (void)fields_.insert(name_);
        
        cpp_.out_
            << cpp_.indent_
            << "out.putField("
            << quote(name_)
            << ", "
            << bitwidth
            << ");\n";
    }
    
    CppFile & cpp_;
    std::string const & name_;
    FieldNames & fields_;
};


/**
 * @brief Functor implementing section name action.
 */
struct SectionName
{
    SectionName(CppFile & cpp)
        : cpp_(cpp)
    {
    }
    
    void
    operator()(Iterator const & first, 
               Iterator const & last) const
    {
        cpp_.out_ 
            << cpp_.indent_ 
            << "out.putSectionName("
            << quote(std::string(first, last))
            << ");\n";
    }
    
    CppFile & cpp_;
};


/**
 * @brief Functor implementing section reference action.
 */
struct SectionRef
{
    SectionRef(CppFile & cpp, std::string const & section_id)
        : cpp_(cpp)
        , section_id_(section_id)
    {
    }
    
    void
    operator()(Iterator const &, 
               Iterator const &) const
    {
        cpp_.out_ 
            << cpp_.indent_ 
            << decodeFunctionName(section_id_)
            << "(out);\n";
    }
    
    CppFile & cpp_;
    std::string const & section_id_;
};


/**
 * @brief Actions structure used when parsing DVB sections
 * @see Section.hpp
 *
 * This structure comprises a set of types used to store values
 * needed by the semantic actions, and the semantic actions
 * themselves.
 */
struct CppActions
{
    CppActions(std::ostream & cpp)
        : cpp_(cpp)
        , enter_block_(cpp_)
        , leave_block_(cpp_)
        , field_(cpp_, field_name_, field_names_)
        , if_(cpp_, if_item_, if_op_, if_value_, field_names_)
        , else_(cpp_)
        , loop_control_(cpp_)
        , loop_start_(cpp_)
        , loop_end_(cpp_)
        , section_name_(cpp_)
        , section_ref_(cpp_, section_id_)
    {
    }

    // The generated output C++ file
    CppFile cpp_;

    // Fields, values etc used to store parsed results
    std::string field_name_;
    std::string section_id_;
    std::string if_item_, if_op_, if_value_;    
    unsigned field_width_;
    FieldNames field_names_;
    
    // Semantic actions
    EnterBlock  enter_block_;
    LeaveBlock  leave_block_;
    Field       field_;
    If          if_;
    Else        else_;
    Loop        loop_control_;
    LoopStart   loop_start_;
    LoopEnd     loop_end_;
    SectionName section_name_;
    SectionRef  section_ref_;
};



/**
 * @brief Generate the decode function for a named section.
 * @param section_name
 * @param cpp The output C++ file
 *
 * This function wraps a call to boost::spirit::parse(), which
 * accepts the section format and the section grammar. As
 * a result of calling this function, the various semantic actions
 * defined above will be exercised, generating the code to decode
 * the section.
 */
void
decodeSection(const char * section_name,
              std::ostream & cpp)
{
    char const * section_format
              = sectionFormat(section_name);
    
    CppActions actions(cpp);
    
    actions.cpp_.out_
        <<
        "\n\n"
        "/**\n"
        " * @brief Generated " << section_name << " decoder\n"
        " */\n"
        "void\n" 
        << decodeFunctionName(section_name) 
        << "(DecodeOut & out)\n";
    
    actions.cpp_.enterBlock();
    
    Section<CppActions> section_grammar(actions);
        
    if (!parse(section_format,
               section_grammar,
               space_p).full)
    {
        throw SectionFormatParseException(section_format);
    }
    
    actions.cpp_.leaveBlock();
}

} // namespace dvbcodec


void
generateDecodeFunctions(std::ostream & cpp,
                        std::ostream & hpp)
{
    typedef std::vector<char const *> sections;
    sections secs;
    
    getKnownSectionFormats(secs);
    
    // Create the decode functions, one per section
    for (sections::const_iterator sec = secs.begin();
         sec != secs.end(); ++sec)
    {
        dvbcodec::decodeSection(*sec, cpp);
    }

    // Create the main decode function
    std::string const main_function =
        "void\n"
        "sectionDecode(char const * section_name,\n"
        "              DecodeOut & out)";

    std::string const main_func_doc =
        "/**\n"
        " * @brief Decode a section\n"
        " * @param section_name\n"
        " * @param out Where to put decode results\n"
        " */\n";


    hpp << "\n\n" << main_func_doc << main_function << ";\n\n";    
    cpp << "\n\n" << main_function << "\n{\n";
    
    for (sections::const_iterator sec = secs.begin();
         sec != secs.end(); ++sec)
    {
        cpp << (sec == secs.begin() ?
                "    if " :
                "    else if ")
            <<  "(std::string(section_name) == " << quote(* sec) + ")\n"
            <<  "    {\n"
            <<  "        " + decodeFunctionName(* sec) + "(out);\n"
            <<  "    }\n";
    }
    cpp <<      "    else\n"
                "    {\n"
                "        throw UnknownSectionException(section_name);\n"
                "    }\n";
    cpp <<      "}\n";
}
