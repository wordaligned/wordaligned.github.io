/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file defines exceptions which can occur when encoding
 * sections
 */

#ifndef ENCODEEXCEPTION_HPP_INCLUDED
#define ENCODEEXCEPTION_HPP_INCLUDED

#include <stdexcept>
#include <string>

/**
 * @brief Encode exception - a bitwidth is not wide enough to encode the
 * supplied value.
 */
class NotEnoughBits
    : public std::runtime_error
{
public:
    NotEnoughBits(unsigned bitwidth)
        : std::runtime_error("Not enough bits to encode value")
        , bitwidth_(bitwidth)
    {
    }
    unsigned bitwidth_;
};


#endif // defined ENCODEEXCEPTION_HPP_INCLUDED

