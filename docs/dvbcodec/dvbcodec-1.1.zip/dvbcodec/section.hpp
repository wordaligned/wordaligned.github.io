/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief  This file defines the Section grammar.
 */

#ifndef SECTION_HPP_INCLUDED
#define SECTION_HPP_INCLUDED

#include <boost/spirit/include/classic_core.hpp>
#include <boost/spirit/include/classic_assign_actor.hpp>


/**
 * @brief Namespace for the DVB section grammar.
 */
namespace dvbcodec
{
using namespace boost::spirit::classic;

/**
 * @brief DVB Section grammar defined using Boost Spirit.
 *
 * References:
 *   - ISO/IEC 13818-1, MPEG-2 Transport Stream
 *   - http://www.boost.org, Boost
 *
 * Users of this grammar need to provide a suitable "Actions"
 * class to implement the various semantic actions.
 */
template <typename Actions>
struct Section :
    public grammar<Section<Actions> >
{
    /**
     * @brief Constructor.
     * @param actions
     */
    Section(Actions & actions)
        : actions_(actions)
    {
    }

    /**
     * @brief The section grammar definition. This comprises a collection
     * of parser rules.
     *
     * (This inner struct is an example of the "Curiously Recurring Template"
     * pattern.)
     */
    template <typename Scanner>
    struct definition
    {
        /**
         * @brief Constructor.
         * @param self A reference to the owning struct.
         */
        definition(Section const & self)
        {
            Actions & actions = self.actions_;
            
            section_
                =   section_ref_          [actions.section_name_]
                    >> block_
                    >> * space_p
                ;

            section_ref_
                =   text_id_              [assign_a(actions.section_id_)]
                    >>   '('
                    >>   ')'
                ;
        
            text_id_
                =   lexeme_d[
                        alpha_p
                        >> * (alnum_p | '_')
                    ]
                ;

            quoted_binary_
                =   lexeme_d[    
                        '\''
                        >>  bin_p
                        >> '\''
                    ]
                ;
            
            item_
               =   field_
                   |   loop_ 
                   |   conditional_
                   |   section_ref_       [actions.section_ref_]
               ;
            
            block_
                =   ch_p('{')             [actions.enter_block_]
                    >> * item_
                    >> ch_p('}')          [actions.leave_block_]
                ;
            
            field_
                =   identifier_           [assign_a(actions.field_name_)]
                    >>   uint_p           [actions.field_]       
                ;

            identifier_
                =   text_id_
                    |   quoted_binary_
                ;

            conditional_
                =   str_p("if")
                    >> condition_         [actions.if_]
                    >> block_
                    >>  ! (str_p("else")  [actions.else_]
                           >>   block_)
                ;

            condition_
                =   '('
                     >> text_id_          [assign_a(actions.if_item_)]
                     >> str_p("==")       [assign_a(actions.if_op_)]
                     >> quoted_binary_    [assign_a(actions.if_value_)]  
                     >> 
                     ')'
                ;

            loop_
                =   loop_control_         [actions.loop_control_]
                    >> ch_p('{')          [actions.loop_start_]
                    >> * item_
                    >> ch_p('}')          [actions.loop_end_]
                ;

            loop_control_
                =   str_p("for")
                    >>   '('
                    >>   * (anychar_p - ')')
                    >>   ')'
                ;

        }
        
        rule<Scanner>
                  section_, section_name_, section_ref_,
                  block_, field_,
                  text_id_, quoted_binary_, identifier_, item_,
                  condition_, conditional_,
                  loop_, loop_control_, loop_start_, loop_end_;

        /**
         * @brief The start() member function required by all Spirit grammars.
         * @returns A reference to the start rule.
         */
        rule<Scanner> const &
        start() const
        {
            return section_;
        }
    };
    
    Actions & actions_;
};

} // namespace dvbcodec

#endif /* defined SECTION_HPP_INCLUDED */

