/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief  This file provides functions to obtain section formats.
 */

#ifndef SECTIONFORMAT_HPP_INCLUDED
#define SECTIONFORMAT_HPP_INCLUDED

#include <vector>

/**
 * @brief Obtain the text format of a section
 * @param section_name
 * @return The section format, if known. 0 otherwise
 * @note The caller should not attempt to free the strings returned 
 * by this function.
 */
char const *
sectionFormat(char const * section_name);

/**
 * @brief Obtain the name of a section
 * @param table_id The id of the table which contains this section
 * @return The section name.
 */
char const *
sectionName(unsigned char table_id);

/**
 * @brief Determine which section formats are known
 * @param formats_to_set
 *
 * @note The caller should not attempt to free the strings returned 
 * by this function.
 */
void
getKnownSectionFormats(std::vector<char const *> &
                       formats_to_set);


#endif /* defined SECTIONFORMAT_HPP_INCLUDED */
