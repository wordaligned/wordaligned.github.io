/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief The main function for the dvbcodec generator.
 */

#include "codectypedefs.hpp"
#include "cppfileutils.hpp"
#include "sectiondecodegenerator.hpp"
#include "sectionformat.hpp"

#include <fstream>
#include <iostream>
#include <sstream>

int
main(int argc, char const * argv[])
{
    int err = 0;

    std::string const outname("sectiondecode");
    std::string filext;
    std::ostringstream cpp;
    std::ostringstream hpp;

    try
    {
        putHeader(cpp, argc, argv);
        putHeader(hpp, argc, argv);
        
        openIncludeGuard(hpp, outname);
        
        forwardDeclareClass(hpp, "DecodeOut");
        includeLocalFile(cpp, "decodeout.hpp");
        includeLocalFile(cpp, "decodeexception.hpp");

        generateDecodeFunctions(cpp, hpp);

        closeIncludeGuard(hpp, outname);
    }
    catch (std::exception const & exc)
    {
        std::cerr << "An exception has occurred.\n\t"
                  << exc.what()
                  << "\nSee .errordump files for context.\n"
                  << std::endl;
        filext = ".errordump";
        ++err;
    }
    std::string cpp_name = outname + ".cpp" + filext;
    std::string hpp_name = outname + ".hpp" + filext;
    
    std::ofstream outcpp(cpp_name.c_str());
    std::ofstream outhpp(hpp_name.c_str());

    std::cout << "Generating files: "
              << hpp_name + ", " + cpp_name
              << std::endl;
    
    outcpp << cpp.str();
    outhpp << hpp.str();

    outcpp.close();
    outhpp.close();
    
    return err;
}
