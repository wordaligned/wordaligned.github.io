/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file contains the implementation of the class DecodeContext.
 */

#include "decodeout.hpp"
#include "decodecontext.hpp"
#include "stringutils.hpp"

namespace
{
/**
 * @brief Convert a string of the form '1010011' (e.g.) into an unsigned long
 */
unsigned long
decodeQuotedBinary(std::string const & quoted_binary_value)
{
    std::string::size_type const len = quoted_binary_value.size();

    assert(len >= 2);
    assert(quoted_binary_value[0] == '\'');
    assert(quoted_binary_value[len - 1] == '\'');
    
    // strip the quotes
    std::string const bin_val =
        quoted_binary_value.substr(1, len - 1);
    
    return std::strtoul(bin_val.c_str(), 0, 2);
}
}

DecodeOut::DecodeOut(std::ostream & out,
                     DecodeContext & context)
    : out_(out)
    , context_(context)
    , depth_(0)
{
}


void
DecodeOut::putSectionName
    (std::string const & section_name) const
{
    out_ << indent() + section_name + "\n";
}


void
DecodeOut::putField(std::string const & field, 
                    unsigned width) const
{
    out_ 
        << indent() + field + " " 
        << width
        << " = 0x" + context_.readFieldValue(field, width)
        << "\n";
}


void
DecodeOut::putLoopControl
    (std::string const & loop_control) const
{
    out_ << indent() + loop_control + "\n";
}


void
DecodeOut::enterBlock()
{
    out_ << indent() + "{\n";
    ++depth_;
}


void
DecodeOut::leaveBlock()
{
    assert(depth_ != 0);
    --depth_;
    out_ << indent() + "}\n";
}


bool
DecodeOut::testLoopExit() const
{
    return context_.testLoopExit();
}


bool
DecodeOut::putIf(std::string const & field,
                 std::string const & op,
                 std::string const & value) const
{
    out_ 
        << indent() 
        << "if (" + field + op + value + ")"
        << "\n";
    
    return context_.testCondition(field, 
                                  op, 
                                  decodeQuotedBinary(value));
}


bool
DecodeOut::putElse()
{
    // Put an empty if-block
    enterBlock();
    leaveBlock();
    
    // Start the else-block
    out_ << indent() + "else\n";
    
    return true;
}


std::string 
DecodeOut::indent() const
{
    std::string const tab("   ");
    return tab * depth_;
}


