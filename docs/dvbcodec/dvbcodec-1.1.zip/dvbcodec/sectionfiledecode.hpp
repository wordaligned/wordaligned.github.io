/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file provides an interface to the DVB section decoder.
 */

#ifndef SECTIONFILEDECODE_HPP_INCLUDED
#define SECTIONFILEDECODE_HPP_INCLUDED


/**
 * @brief Decode a binary DVB section
 * @param file_name The name of the file
 *
 * @note This function may throw file system exceptions (see
 * filesysexception.hpp), but should not throw decoder exceptions.
 */
void
sectionFileDecode(char const * file_name);


#endif // SECTIONFILEDECODE_HPP_INCLUDED

