/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief  This file provides some string handling utilities.
 */

#ifndef STRINGUTILS_HPP_INCLUDED
#define STRINGUTILS_HPP_INCLUDED

#include <string>

/**
 * @brief String extension change utility
 * @return A string based on the input string, its extension changed
 * to the new extension.
 * 
 * Examples: 
 *    changeExtension("section.bin", ".txt") --> "section.txt" <br>
 *    changeExtension("section", ".txt") --> "section.txt"     <br> 
 */
std::string
changeExtension(std::string const & to_change,
                std::string const & new_ext);


/**
 * @returns The input string repeated by the input multiplier
 * 
 * Example
 *    "XX" * 3 --> "XXXXXX"
 */
std::string 
operator*(std::string const & to_multiply,
          unsigned multiplier);


/**
 * @returns True if the test string ends with the supplied ending.
 * 
 * Example
 *     endsWith("section_length", "length") --> true
 */
bool
endsWith(std::string const & test_string,
         std::string const & ending);


/**
 * @return An uppercase version of the input string.
 */
std::string
upperCase(std::string const & to_convert);

#endif // STRINGUTILS_HPP_INCLUDED
