/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief  This file provides some utilities for creating CPP files.
 */

#ifndef CPPFILEUTILS_HPP_INCLUDED
#define CPPFILEUTILS_HPP_INCLUDED

#include <ostream>
#include <string>

/**
 * @brief Puts the standard file header (for generated files)
 * to the CPP file
 */
void 
putHeader(std::ostream & os, int argc, char const * argv[]);


/**
 * @brief Opens the include guard for an HPP file
 */
void
openIncludeGuard(std::ostream & hpp, 
                 std::string const & basename);


/**
 * @brief Closes the include guard for an HPP file
 */
void
closeIncludeGuard(std::ostream & hpp, 
                  std::string const & basename);


/**
 * @brief Return the name of the decode function for 
 * the input section
 */
std::string
decodeFunctionName(std::string const & section_name);


/**
 * @brief Forward declare a class in a source file
 */
void
forwardDeclareClass(std::ostream & cpp,
                    std::string const & class_name);


/**
 * @brief Include a "local" file
 * 
 * Example:
 * includeLocalFile(cpp, "section.hpp") 
 * puts 
 * #include "section.hpp"
 */
void
includeLocalFile(std::ostream & cpp,
                 std::string const & to_include);

#endif // CPPFILEUTILS_HPP_INCLUDED
