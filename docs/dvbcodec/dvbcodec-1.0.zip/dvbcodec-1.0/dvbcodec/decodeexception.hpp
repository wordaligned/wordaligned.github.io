/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file defines exceptions which can occur when decoding
 * sections.
 */

#ifndef DECODEEXCEPTION_HPP_INCLUDED
#define DECODEEXCEPTION_HPP_INCLUDED

#include <stdexcept>
#include <string>

/**
 * @brief Exception class for use if a section is encountered which the DVB
 * codec does not recognise.
 */
 class UnknownSectionException
    : public std::runtime_error
{
public:
    UnknownSectionException(std::string const & section)
        : std::runtime_error
            (std::string("Section [")
             + section
             + "] not supported")
    {
    }
};


/**
 * @brief Exception class for use if a section format is encountered which the DVB
 * codec cannot parse, either due to an error in the DVB codec section grammar
 * or due to an error in the registered section format.
 */
class SectionFormatParseException
    : public std::runtime_error
{
public:
    SectionFormatParseException(std::string const & format)
        : std::runtime_error
            (std::string("Failed to parse format of section [")
             + format
             + "]")
    {
    }                            
};


/**
 * @brief Exception class for use if the DVB codec reaches the end of the
 * input section data before completely decoding the section.
 */
class EndOfDataException
    : public std::runtime_error
{
public:
    EndOfDataException()
        : std::runtime_error(
            std::string("Section incomplete")
            )
    {
    }
};


/**
 * @brief Exception class for use if the DVB codec completes the decode
 * of a section before the end of the section file.
 */
class SectionFinishedBeforeEof
    : public std::runtime_error
{
public:
    SectionFinishedBeforeEof()
        : std::runtime_error(
            std::string(
                "Section decoded before end of file reached"
                )
            )
    {
    }
};


/**
 * @brief Exception class for use if the DVB codec encounters a
 * malformed conditional -- for example one which tests the value of a field
 * which does not exist in the section.
 */
class MalformedConditional
    : public std::runtime_error
{
public:
    MalformedConditional(std::string const & field)
        : std::runtime_error(
            std::string("Section conditional references unknown field ["
                        + field
                        + "]"
                        )
            )
    {
    }
};

/**
 * @brief Exception class for use if a length field does not start at an
 * 8 bit boundary.
 */
class BadlyAlignedBlockExit
    : public std::runtime_error
{
public:
    BadlyAlignedBlockExit(std::string const & field)
        : std::runtime_error(
            std::string("Length field ["
                        + field
                        + "] is not at an 8 bit boundary"
                        )
            )
    {
    }
};


#endif // defined DECODEEXCEPTION_HPP_INCLUDED

