/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file provides an interface to the section decoder generator.
 */

#ifndef SECTIONDECODEGENERATOR_HPP_INCLUDED
#define SECTIONDECODEGENERATOR_HPP_INCLUDED

#include <iosfwd>

void
generateDecodeFunctions(std::ostream & cpp, std::ostream & hpp);


#endif // SECTIONDECODEGENERATOR_HPP_INCLUDED

