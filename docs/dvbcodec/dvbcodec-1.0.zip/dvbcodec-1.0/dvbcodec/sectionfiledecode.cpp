/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief DVB section decoder support.
 */
#include "sectiondecode.hpp"
#include "decodecontext.hpp"
#include "decodeexception.hpp"
#include "decodeout.hpp"
#include "filesysexception.hpp"
#include "sectionformat.hpp"
#include "stringutils.hpp"

#include <fstream>
#include <sstream>
#include <iostream>
#include <string>

namespace
{

DecodeContext
createDecodeContext(char const * file_name,
                    char const * & section_name)
{
    file_it file_begin(file_name);

    if (!file_begin)
    {
        throw FailedToOpenFile(file_name);
    }
    file_it file_end = file_begin.make_end();

    if (file_begin == file_end)
    {
        throw EmptyFileException(file_name);
    }
    
    section_name = sectionName(*file_begin);

    return DecodeContext(file_begin, file_end);
}

} // anonymous namespace


void
sectionFileDecode(char const * file_name)
{
    char const * section_name = 0;
    std::ostringstream out;
        
    DecodeContext context
        = createDecodeContext(file_name, section_name);
    
    DecodeOut decode_out(out, context);
    
    std::string text_file_name
        = changeExtension(file_name, ".txt");

    // Note: any decode errors are handled at this level --
    // the output "errordump" should provide useful context.
    // File system errors (e.g failure to open a file) must be
    // handled by callers of this function.
    try
    {
        sectionDecode(section_name, decode_out);
        
        if (!context.finished())
        {
            throw SectionFinishedBeforeEof();
        }
    }
    catch (std::exception & exc)
    {
        std::cerr
            << "Failed to decode [" << file_name << "]\n"
            << exc.what()
            << std::endl;
        text_file_name
            = changeExtension(file_name, ".errordump");
    }
    
    std::ofstream outf(text_file_name.c_str());
    
    if (!outf)
    {
        throw FailedToOpenFile(text_file_name);
    }
    outf << out.str();
    std::cout
        << "Decode: [" << file_name
        << "] --> [" << text_file_name << "]" << std::endl;
}
