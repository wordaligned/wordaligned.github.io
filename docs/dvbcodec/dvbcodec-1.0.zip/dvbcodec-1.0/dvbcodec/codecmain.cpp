/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief The main function for the dvbcodec 
 */
#include "sectionfiledecode.hpp"
#include "sectionencode.hpp"
#include "sectionformat.hpp"

#include <string>
#include <vector>
#include <iostream>

typedef std::vector<char const *> Names;

/**
 * @brief Enumeration of modes for the DVB codec
 */
enum CodecMode
{
    // decode binary sections
    decode,
    // encode text sections
    encode,
    // provide information only
    info
};


namespace
{

/**
 * @brief Process the codec command line options
 * @param argc
 * @param argv
 * @param first_file Set to the index into the command line args 
 * of the name of the first file to process. Will be set to argc
 * if no files should be processed
 *  @returns The codec mode
 */
CodecMode
processOptions(int argc, char * argv[], int & first_file)
{
    // The default action is to decode the files supplied as
    // command line options.
    CodecMode mode = decode;
    first_file = 1;
    
    std::string const title("DVB-Codec Version 1.0");
    
    std::string const usage =
        title + "\n"
        + "Usage: " 
        + argv[0] + " [-option] [<files>*]\n"
          "where option can be one of\n"
          "    -e encode text files (the default is to decode binary files)\n"
          "    -h print this help and exit\n"
          "    -l list supported DVB sections and exit.\n\n";
    
    if (argc > 1)
    {
        std::string const opt(argv[1]);
        
        if (opt == "-e")
        {
            ++first_file;
            mode = encode;
        }
        else if (opt == "-h")
        {
            std::cout << usage;
            mode = info;
        }
        else if (opt == "-l")
        {
            mode = info;
            std::cout << title + "\nSupported sections:\n";
            Names secs;
            getKnownSectionFormats(secs);
            
            for (Names::const_iterator sec = secs.begin();
                 sec != secs.end(); ++sec)
            {
                std::cout << "\t" << *sec << "\n";
            }
        }
    }
    else
    {
        std::cout << usage;
        mode = info;
    }
    return mode;
}


void
processFile(CodecMode mode, char const * file_name)
{
    if (mode == decode)
    {
        sectionFileDecode(file_name);
    }
    else
    {
        sectionEncode(file_name);
    }
}

} // anonymous namespace

int
main(int argc, char * argv[])
{
    int err = 0;
    
    int first_file;
    
    CodecMode const mode = processOptions(argc, argv, first_file);
    
    if (mode != info)
    {
        // Loop through any supplied files, exiting as soon as 
        // an exception is thrown.
        int i = first_file;
        try
        {
            for ( ; i < argc ; ++i)
            {
                processFile(mode, argv[i]);
            }
        }
        catch (std::exception & exc)
        {
            std::cerr 
                << "Error processing ["
                << argv[i] << "]\n"
                << exc.what() << std::endl;
            
            err = -1;
        }
    }
    return err;
}
