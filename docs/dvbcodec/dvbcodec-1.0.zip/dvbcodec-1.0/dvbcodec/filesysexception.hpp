/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief  This file exceptions related to binary section files.
 */

#ifndef FILESYSEXCEPTION_HPP_INCLUDED
#define FILESYSEXCEPTION_HPP_INCLUDED

#include <stdexcept>

/**
 * @brief Exception used if a file cannot be opened.
 */
class FailedToOpenFile
    : public std::runtime_error
{
public:
    FailedToOpenFile(std::string const & file_name)
        : std::runtime_error(
             std::string("Failed to open file [") 
             + file_name
             + "]\n")
    {
    }
};


/**
 * @brief Exception used if a file is empty (binary sections may not
 * be empty).
 */
class EmptyFileException
    : public std::runtime_error
{
public:
    EmptyFileException(std::string const & file_name)
        : std::runtime_error(
             std::string("File [") 
             + file_name
             + "] is empty\n")
    {
    }
};

#endif // defined FILESYSEXCEPTION_HPP_INCLUDED

