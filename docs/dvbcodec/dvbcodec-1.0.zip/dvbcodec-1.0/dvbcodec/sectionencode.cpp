/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief DVB section encoder support
 */

#include "codectypedefs.hpp"
#include "encodeexception.hpp"
#include "filesysexception.hpp"
#include "stringutils.hpp"

#include <boost/spirit/core.hpp>

#include <cassert>
#include <cctype>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>


using namespace boost::spirit;
typedef std::string::const_iterator iter;

namespace
{

/**
 * @returns True iff v is in the range [lo, hi] (inclusive)
 */
bool
inRange(unsigned v, unsigned lo, unsigned hi)
{
    return v >= lo && v <= hi;
}


char const *
binaryString(byte hex_digit)
{
    hex_digit = std::tolower(hex_digit);
    
    assert(inRange(hex_digit, '0', '9') ||
           inRange(hex_digit, 'a', 'f'));
    
    static char const * bin[0x10] =
    {
        "0000", "0001", "0010", "0011",
        "0100", "0101", "0110", "0111",
        "1000", "1001", "1010", "1011",
        "1100", "1101", "1110", "1111",
    };
    
    unsigned const ix 
              = inRange(hex_digit, '0', '9') 
              ? hex_digit - '0'
              : hex_digit - 'a' + 10;
    
    return bin[ix];
}


/**
 * @brief Functor which appends hex digits to a binary string
 * representation
 */
struct HexToBin
{
    HexToBin(std::string & bin)
        : bin_(bin)
    {
    }
    
    void operator()(byte hex_digit) const
    {
        bin_ += binaryString(hex_digit);
    }
    
    std::string & bin_;
};


/**
 * @brief Extract bits from a binary string
 * @param bin A string of binary values
 * @param from The bit index to read from
 * @param to The bit index to read to (exclusive).
 * @side-effect Clears values read (for self-check purposes)
 */
unsigned
extractBits(std::string & bin,
            unsigned from,
            unsigned to)
{
    assert(to > from && to - from <= 8);
    assert(from < bin.size() && to <= bin.size());
    
    unsigned enc = 0x0;
    
    for ( ; from != to; ++from)
    {
        enc <<= 1;
        enc |= bin[from] - '0';
        bin[from] = '0';
    }
    
    return enc;
}


/**
 * @brief Ouput the input value to the output stream 
 * using the specified bit width
 */
void
putBits(std::ostream & out,
        unsigned bitwidth,
        std::string & bin)
{
    static unsigned to_fill = 8;
    static unsigned char byte = 0x0;
    
    if (bitwidth > bin.size())
    {
        throw NotEnoughBits(bitwidth);
    }
    unsigned const trim = bin.size() - bitwidth;

    if (bin.substr(0, trim).find_first_not_of('0')
        != std::string::npos)
    {
        throw NotEnoughBits(bitwidth);
    }
    bin = bin.substr(trim);
    
    for (unsigned bits_read = 0; bits_read != bitwidth; )
    {
        unsigned to_read = std::min(to_fill, 
                                    bitwidth - bits_read);
        
        unsigned read = extractBits(bin, 
                                    bits_read, 
                                    bits_read + to_read);
        
        byte |= read << to_fill - to_read;
                  
        to_fill -= to_read;
        bits_read += to_read;
        
        if (to_fill == 0)
        {
            // A byte has been filled - put to output
            // and reset for next byte.
            out << byte;
            byte = 0x0;
            to_fill = 8;
        }
    }
    
    // Check we've cleared all the '1's from the string
    assert(bin.find_first_not_of('0') == std::string::npos);
}



/**
 * @brief Parse a field of the form:
 * <field_name> <bitwidth> = <value>
 * @returns True if the field matches the format,
 * false otherwise.
 */
bool
parseField(iter const & begin, iter const & end,
           unsigned & bitwidth, std::string & bin)
{
    // Note: we do not use hex_p (for example) to capture the 
    // hexadecimal string, since this limits values to the 
    // size of unsigned ints.
    // What we'd really like is an arbitrary sized int...
    return parse(
             
         begin, 
         end,
         
         lexeme_d[+graph_p]
         >>   uint_p                     [assign_a(bitwidth)]
         >>   '='
         >>   lexeme_d
              [
                  ! as_lower_d["0x"]
                  >>  + xdigit_p         [HexToBin(bin)]
              ]
         ,
         
         space_p).full;
}

} // anonymous namespace


void
sectionEncode(char const * file_name)
{
    std::ifstream in(file_name);
    
    if (!in)
    {
        throw FailedToOpenFile(file_name);
    }
    
    std::string bin_file_name
         = changeExtension(file_name, ".bin");
    
    std::ostringstream out(std::ios::binary);
    
    int line = 0;
    std::string str;
    
    // Note: any encode errors are handled at this level --
    // the output "errordump" should provide useful context.
    // File system errors (e.g failure to open a file) must be
    // handled by callers of this function.
    try 
    {
        while (std::getline(in, str))
        {
            ++line;
        
            unsigned bitwidth;
            std::string bin;
            
            if (parseField(str.begin(), str.end(), 
                           bitwidth, bin)) 
            {
                putBits(out, bitwidth, bin);
            }
        }
    }
    catch (std::runtime_error & rte)
    {
        std::cerr
            << "Error encoding line [" << line
            << "], [" << str << "]" << "\n"
            << rte.what() << std::endl;
        bin_file_name += ".error";
    }
    
    std::ofstream outf(bin_file_name.c_str(),
                       std::ios::binary);
    
    if (!outf)
    {
        throw FailedToOpenFile(bin_file_name);
    }
    
    outf << out.str(); 
    std::cout
        << "Encode: [" << file_name
        << "] --> [" << bin_file_name << "]" << std::endl;
}
