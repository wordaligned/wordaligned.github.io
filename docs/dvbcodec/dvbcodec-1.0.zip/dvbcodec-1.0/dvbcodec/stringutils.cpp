/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief  This file implements some string handling utilities.
 */

#include "stringutils.hpp"
#include <sstream>
#include <cctype>

std::string
changeExtension(std::string const & to_change,
                std::string const & new_ext)
{
    return
        std::string(to_change,
                    0,
                    to_change.find_last_of('.'))
        + new_ext;
}


std::string 
operator*(std::string const & to_multiply,
          unsigned multiplier)
{
    std::string result;
    
    while (multiplier-- != 0)
    {
        result += to_multiply;
    }
    
    return result;
}


bool
endsWith(std::string const & test_string,
         std::string const & ending)
{
    std::string::size_type const end_len = ending.size();
    std::string::size_type const test_len = test_string.size();

    return
        test_len >= end_len &&
        test_string.compare(test_len - end_len,
                            end_len,
                            ending) == 0;
}


std::string
upperCase(std::string const & lower)
{
    std::string upper = lower;
    
    for (std::string<char>::iterator cc = upper.begin();
         cc != upper.end(); ++cc)
    {
        * cc = std::toupper(* cc);
    }
    
    return upper;
}
