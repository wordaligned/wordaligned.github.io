/**
 * Copyright (c) 2004, Thomas Guest.
 * @file
 * @brief This file defines some typedefs used in the codec 
 * for convenience.
 */

#ifndef CODECTYPEDEFS_HPP_INCLUDED
#define CODECTYPEDEFS_HPP_INCLUDED

#include <boost/spirit/tree/ast.hpp>
#include <boost/spirit/iterator/file_iterator.hpp>

typedef unsigned char byte;
typedef boost::spirit::file_iterator<byte> file_it;

typedef char const * Iterator;

#endif /* defined CODECTTYPEDEFS_HPP_INCLUDED */

